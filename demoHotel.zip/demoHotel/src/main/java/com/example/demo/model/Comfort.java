package com.example.demo.model;

public enum Comfort {Standart,Halflux,Lux
}
