package com.example.demo.forms;

import java.time.LocalDate;

public class CheckingForm {
    private String id;
    private String guest;
    private String room;
    private String checkIn;
    private String checkOut;
    private boolean Reserved=false;


    public CheckingForm() {
    }

    public CheckingForm(String guest, String room, String checkIn, String checkOut) {
        this.guest = guest;
        this.room = room;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGuest() {
        return guest;
    }

    public void setGuest(String guest) {
        this.guest = guest;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(String checkIn) {
        this.checkIn = checkIn;
    }

    public String getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(String checkOut) {
        this.checkOut = checkOut;
    }

    public boolean isReserved() {
        return Reserved;
    }

    public void setReserved(boolean reserved) {
        Reserved = reserved;
    }

    @Override
    public String toString() {
        return "CheckingForm{" +
                "id='" + id + '\'' +
                ", guest='" + guest + '\'' +
                ", room='" + room + '\'' +
                ", checkIn='" + checkIn + '\'' +
                ", checkOut='" + checkOut + '\'' +
                ", Reserved=" + Reserved +
                '}';
    }
}
